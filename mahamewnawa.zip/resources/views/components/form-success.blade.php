<div class="mx-auto max-w-2xl text-center">
    <p class="mt-2 text-lg leading-8 text-green-600">{{ $message }}</p>
</div>