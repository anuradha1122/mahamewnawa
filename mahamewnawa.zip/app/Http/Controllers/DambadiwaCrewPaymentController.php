<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreDambadiwaCrewPaymentRequest;
use App\Http\Requests\UpdateDambadiwaCrewPaymentRequest;
use App\Models\DambadiwaCrewPayment;

class DambadiwaCrewPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDambadiwaCrewPaymentRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DambadiwaCrewPayment $dambadiwaCrewPayment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DambadiwaCrewPayment $dambadiwaCrewPayment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDambadiwaCrewPaymentRequest $request, DambadiwaCrewPayment $dambadiwaCrewPayment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DambadiwaCrewPayment $dambadiwaCrewPayment)
    {
        //
    }
}
